<?php
include('include/header.php');
?>
<div>
	<div class="container-fluid bg-danger mb-2 mt-2">
		<h5 class="text-white text-center text-capitalized text-italic mb-2 mt-3">Here we serve not only delicious food although we serve happiness as well as good memory</h5>
	</div>
	

<div class="flex-container mx-auto" >
      <div><img src="public/assest/images/event1.jpeg" class="gall"> </div> 
      	<div><img src="public/assest/images/food3.jpeg" class="gall"></div>
      	<div><img src="public/assest/images/dacoration.jpeg" class="gall"></div>
      	<div><img src="public/assest/images/live.jpeg" class="gall"></div>
      	<div><img src="public/assest/images/6-1.jpg" class="gall"></div>
      	<div><img src="public/assest/images/4.jpg" class="gall"></div>
      	<div class="flex-container">
      <div><img src="public/assest/images/food2.jpeg" class="gall"> </div> 
      	<div><img src="public/assest/images/fam.jpeg" class="gall"></div>
      	<div><img src="public/assest/images/buffet.jpg" class="gall"></div>
      	<div><img src="public/assest/images/food1.jpeg" class="gall"></div>
      	<div><img src="public/assest/images/hol.jpeg" class="gall"></div>
      	<div><img src="public/assest/images/cop.jpeg" class="gall"></div>
         </div>
         </div>

        

</div>
<?php
include('include/footer.php');
?>