<?php
include('include/header.php');
?>
<div>
	<div class="bg-warning">
		<h4 class="text-danger text-center text-capitalized font-weight-bold mt-2 mb-3">WE SERVE HAPPINESS</h4>
	</div>
<div class="article">
    <div class="container-fluid bg-light mt-2">
    	<div class="row">
    		<div class="container col-md-6 ">
    			<div class="mt-3 text-center">
    				<div class="text-danger text-capitalized text-justify">
    					<h2 class="text-center"><i class="fa fa-map-marker"></i>OUR ADDRESS</h2>
    					
    					<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3560.545583161488!2d75.8633743757248!3d26.822594176700996!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x396db770070b115f%3A0x6f306afd08a3e737!2sSwami%20Keshvanand%20Institute%20of%20Technology%2C%20Management%20%26%20Gramothan%20(SKIT)!5e0!3m2!1sen!2sin!4v1722605808315!5m2!1sen!2sin" width="500" height="250" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
    				</div>
    			</div>
    			
    		</div>
    	   


    	   <div class="container  col-md-6 ">
    			<div class="mt-3 text-center">
    				<div class="text-danger text-capitalized text-justify">
    				<h2 calss="text-center"><i class="fa fa-phone"></i>  CONTACT US</h2>
    				<p class="text-warning text-center text-uppercase lead">OUR friendly team is here to help you</p>
    				<h6 class="text-dark text-justify">PHONE: +910123456789</br></br>
    				   EMAIL: abc@gmail.com

    				</h6>
      				<h2 class="text-secondary text-uppercase mb-0 mt-3">follow us</h2>

      				  <a href="#" class="fa fa-instagram fa-lg"></a>
      				 <a href="#" class="fa fa-whatsapp fa-lg"></a>
      				 <a href="#" class="fa fa-youtube-play fa-lg"></a>
      				
      				
      				
    				 
    					
    				</div>
    			</div>
    			
    		</div>




        </div>

    </div>
</div>


 <?php
include('include/footer.php');
?> 