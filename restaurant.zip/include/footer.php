
<footer>
	<div class=" container">
      <div class="row">
      	<div class="container col-md-3 p-5">
      		<div class="footer-content">
      			<div class="footer-description">
      				<h2 class="sub-title"><span class="icon"><i class="fa fa-map-marker"></i> </span><br>
      				Address </h2>
      				Ramnagriya road,near Swami keshvanand institute of technology and Gramothan,jaipur,Rajasthan
      			</div>
      		</div>
      	</div>
      	<div class="container col-md-3 p-5">
      		<div class="footer-content">
      			<img src="public/assest/images/7.jpg " width="250">
      			<form class="d-flex">
      				<input type="text" id="utext" placeholder="Give your feedback"> 
      				<button type="submit" class="btn btn-succes bg-warning f-button" onclick="return testing()">click here</button>
      			</form>
      		</div>
      	</div>
      	<div class=" container col-md-3 p-5">
      		<div class="footer-content">
      			<div class="footer-description">
      				
      				 <a href="#" class="fa fa-instagram"></a>
      				 <a href="#" class="fa fa-whatsapp"></a>
      				 <a href="#" class="fa fa-youtube-play"></a>
      				
      				<br>
      				<h2 class="sub-title">follow us</h2>

      		</div>
      		</div>
      	</div>
      	<div class=" container col-md-3 p-5">
      		<div class="footer-content">
      			<div class="footer-description">
      				<span class="icon"><i class="fa fa-phone"></i></span>
      				<h2 class="sub-title">Contact us</h2>
      				<p class="cont"> phone:+910123456789</p>
      				<p class="cont">Email:abc@gmail.com</p>
      				
      				 

      		</div>
      		</div>
      	</div>
      	
      </div>
	</div>

	
</footer>
</body>
</html>
